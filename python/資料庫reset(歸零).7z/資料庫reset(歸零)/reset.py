import pymysql

# open a cursor to the database
conn = pymysql.connect(host="localhost",user="root",passwd="",db="bus")
mycursor = conn.cursor()


reset = input("請輸入要reset的路線:")

if reset=='1579A':
   mycursor.execute("UPDATE 1579A SET 預約人數=0 WHERE 預約人數>0")
   print("1579A")
elif reset=="1579B":
   mycursor.execute("UPDATE 1579B SET 預約人數=0 WHERE 預約人數>0")
   print("1579B")

elif reset=="all":   
   mycursor.execute("UPDATE 1579A SET 預約人數=0 WHERE 預約人數>0") 
   mycursor.execute("UPDATE 1579B SET 預約人數=0 WHERE 預約人數>0")   
   print("all")
conn.commit()