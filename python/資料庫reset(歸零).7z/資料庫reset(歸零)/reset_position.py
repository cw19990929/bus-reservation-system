import pymysql

# open a cursor to the database
conn = pymysql.connect(host="localhost",user="root",passwd="",db="bus")
mycursor = conn.cursor()

mycursor.execute("UPDATE position SET address=0 WHERE address>0")
print("all")

conn.commit()