import pymysql

# open a cursor to the database
conn = pymysql.connect(host="localhost",user="root",passwd="",db="bus")
mycursor = conn.cursor()

mycursor.execute("UPDATE total SET 總人數=0 WHERE 總人數>0")
print("all")

conn.commit()